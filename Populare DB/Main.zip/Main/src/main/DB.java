/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Chirila Loredana, Gavriliuc Samuel
 */
public class DB {

    private static final String URL = "jdbc:oracle:thin:@ec2-54-245-171-25.us-west-2.compute.amazonaws.com:1521:orcl";
    private static final String USER = "STUD";
    private static final String PASSWORD = "studip";
    private static Connection connection = null;

    private DB() {
    }

    public static Connection GetConn() throws SQLException {
        if (connection == null) {
            createConnection();
        }
        return connection;
    }

    private static void createConnection() throws SQLException {
        System.out.println("Connecting.");
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    static void closeConnection() throws SQLException {
        try {
            //Statement stmt = connection.createStatement();
            //ResultSet rs = stmt.executeQuery("select id from matches");
            connection.close();
            //rs.close();
        } catch (SQLException e) {
            System.err.println("SQLException: " + e);
        }
    }

    static void commit() throws SQLException {
        try {
            connection.setAutoCommit(false);
            System.out.println("Commiting.");
            connection.commit();
        } catch (SQLException e) {
            System.err.println("SQLException: " + e);
            e.printStackTrace();
        }
    }

    static void rollback() {
        System.out.println("Rolling back data.");
        try {
            if (connection != null) {
                connection.rollback();
            }
        } catch (SQLException e) {
            System.err.println("SQLException: " + e);
            e.printStackTrace();
        }
    }
}

