/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Main {

    public static void main(String argv[]) throws SAXException, ParserConfigurationException, SQLException {

        String name = CV.getName("E:\\Downloads\\IP\\Aaron Oeder.xml");
        String email = CV.getEmail("E:\\Downloads\\IP\\Aaron Oeder.xml");
        List<WorkExperience> workExperience = CV.getWorkExperience("E:\\Downloads\\IP\\Aaron Oeder.xml");

        CV.getStudiesExperience("E:\\Downloads\\IP\\Aaron Oeder.xml");
        List<String> skills = CV.getSkills("E:\\Downloads\\IP\\Aaron Oeder.xml");
        Connection con = DB.GetConn();
        int var = 0;
        PreparedStatement pstmt;
        pstmt = con.prepareStatement("insert into curriculumvitae (id,name,email) values (?,?,?)");

        pstmt.setInt(1, 10);
        pstmt.setString(2, name);
        pstmt.setString(3, email);
        pstmt.executeUpdate();
        for (int i = 0; i < workExperience.size(); i++) {
            pstmt = con.prepareStatement("insert into experience (cv_id,job_title,experience_years) values (?,?,?)");
            pstmt.setInt(1, 10);
            pstmt.setString(2, workExperience.get(i).jobTitle);
            pstmt.setInt(3, workExperience.get(i).experienceYears);
            pstmt.executeUpdate();
            var += workExperience.get(i).experienceYears;
        }
        pstmt = con.prepareStatement("update curriculumvitae set experience_years = (?) where id =10");

        pstmt.setInt(1, var);
        pstmt.executeUpdate();
        for (int i = 0; i < skills.size(); i++) {
            pstmt = con.prepareStatement("insert into softskills (cv_id,skill) values (?,?)");
            pstmt.setInt(1, 10);
            pstmt.setString(2, skills.get(i));
            pstmt.executeUpdate();
        }

        /*Statement stmt = con.createStatement();
        ResultSet rs;
        String query;
 int c=0;
        for(int i=0;i<skills.size();i++){
            query = "select skill from technical_skills where skill= '" + skills.get(i) + "'";
            rs = stmt.executeQuery(query);
            if(rs == null){
                while(rs.next()){
                    c = rs.getInt("technical_skill_id");
                }
                c++;
                pstmt = con.prepareStatement("insert into technical_skill (technical_skill_id,skill) values (?,?)");
                pstmt.setInt(1, c);
                pstmt.setString(2, skills.get(i));
                pstmt.executeUpdate();
            }
        }
 /*try {

	File fXmlFile = new File("D:\\Facultate\\Anul 2\\Semestrul 2\\IP\\Proiect\\Aaron-Metcalfe.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);

	doc.getDocumentElement().normalize();

	NodeList nList = doc.getElementsByTagName("PersonName");
        
        for (int i = 0; i < nList.getLength(); i++) 
        {
            Node nNode = nList.item(i);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;
			System.out.println(eElement.getElementsByTagName("FormattedName").item(0).getTextContent());
		}
        }

	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

			System.out.println("Staff id : " + eElement.getAttribute("id"));
			System.out.println("First Name : " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
			System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
			System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
			System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());

		}
	}
   } catch (ParserConfigurationException | SAXException | IOException | DOMException e) {
    }*/
    }

}
