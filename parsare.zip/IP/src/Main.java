
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;


public class Main {

    public static void main(String argv[]) throws SAXException, ParserConfigurationException {

        String name=CV.getName("C:\\Users\\Grozavu\\Desktop\\XML\\Aaron-Metcalfe.xml");
        String email=CV.getEmail("C:\\Users\\Grozavu\\Desktop\\XML\\Aaron-Metcalfe.xml");
        List<WorkExperience> workExperience=CV.getWorkExperience("C:\\Users\\Grozavu\\Desktop\\XML\\Aaron-Metcalfe.xml");
        CV.getStudiesExperience("C:\\Users\\Grozavu\\Desktop\\XML\\Aaron-Metcalfe.xml");
        List<String> skills =CV.getSkills("E:\\An2-Sem2\\IP\\XML files\\Aaron-Metcalfe.xml");
        for(int i=0;i<skills.size();i++)
            System.out.println(skills.get(i));
//    try {
//
//	File fXmlFile = new File("C:\\Users\\Grozavu\\Desktop\\XML\\Aaron-Metcalfe.xml");
//	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//	Document doc = dBuilder.parse(fXmlFile);
//
//	doc.getDocumentElement().normalize();
//
//	NodeList nList = doc.getElementsByTagName("PersonName");
//        
//        for (int i = 0; i < nList.getLength(); i++) 
//        {
//            Node nNode = nList.item(i);
//            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//			Element eElement = (Element) nNode;
//			System.out.println(eElement.getElementsByTagName("FormattedName").item(0).getTextContent());
//		}
//        }
//
////	System.out.println("----------------------------");
////
////	for (int temp = 0; temp < nList.getLength(); temp++) {
////
////		Node nNode = nList.item(temp);
////
////		System.out.println("\nCurrent Element :" + nNode.getNodeName());
////
////		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
////
////			Element eElement = (Element) nNode;
////
////			System.out.println("Staff id : " + eElement.getAttribute("id"));
////			System.out.println("First Name : " + eElement.getElementsByTagName("firstname").item(0).getTextContent());
////			System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
////			System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
////			System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());
////
////		}
////	}
//    } catch (Exception e) {
//	e.printStackTrace();
//    }
    }

}
