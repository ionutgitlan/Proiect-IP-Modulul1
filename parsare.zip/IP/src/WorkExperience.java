/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Grozavu
 */
public class WorkExperience {
    String jobTitle;
    int experienceYears;
    
    public WorkExperience(String title,int experienceYears){
        this.experienceYears=experienceYears;
        this.jobTitle=title;
    }
    
    public String getJobTitle(){
        return this.jobTitle;
    }
    
    public int getExperienceYears(){
        return this.experienceYears;
    }
}
